# STOCK-RETURN-PREDICTION-USING-KNN-SVM-GUASSIAN-PROCESS-ADABOOST-TREE-REGRESSION-AND-QDA
Forecast stock prices using machine learning approach. A time series analysis. Employ the Use of Predictive Modeling in Machine Learning to Forecast Stock Return. Approach Used by Hedge Funds to Select Tradeable Stocks


Objective:

          Predict stock stock price using Technical Indicators as predictors.
          Use Supervised Machine Learning Approach to predict stock price both on train and test data.
          Employ the use of pipeline to and GridSearch to select the model model
          Use Final Model to Predict Stock Returns.
          SHow plots of stock Return
          Write Deployable script.

How to Use

          >git clone https://github.com/kennedyCzar/STOCK-RETURN-PREDICTION-USING-KNN-SVM-GUASSIAN-PROCESS-ADABOOST-TREE-REGRESSION-AND-QDA
          Unpak the Files in a project folder
          
          Add File Path to Environment Variable using Spyder PythonPath
          
          Click on Synchronize with Environment.
          
          Restart Spyder.
          
          Report Issue
          
